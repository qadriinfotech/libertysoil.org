<?php
define('CUSTOM_MENU_CAT_LABEL',__('Categories',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_TITLE',__('Categories',ADMINDOMAIN));
define('CUSTOM_MENU_SIGULAR_CAT',__('Category',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_SEARCH',__('Search category',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_POPULAR',__('Popular categories',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_ALL',__('All categories',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_PARENT',__('Parent category',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_PARENT_COL',__('Parent category:',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_EDIT',__('Edit category',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_UPDATE',__('Update category',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_ADDNEW',__('Add new category',ADMINDOMAIN));
define('CUSTOM_MENU_CAT_NEW_NAME',__('New category name',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_LABEL',__('Tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_TITLE',__('Tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_NAME',__('Tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_SEARCH',__('Tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_POPULAR',__('Popular tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_ALL',__('All tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_PARENT',__('Parent tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_PARENT_COL',__('Parent tags:',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_EDIT',__('Edit tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_UPDATE',__('Update tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_ADD_NEW',__('Add new tags',ADMINDOMAIN));
define('CUSTOM_MENU_TAG_NEW_ADD',__('New tag name',ADMINDOMAIN));
define('FLD_REQUIRED_TEXT',__('*',ADMINDOMAIN));

define('GRID_VIEW_TEXT',__('Grid view',ADMINDOMAIN));
define('LIST_VIEW_TEXT',__('List view',ADMINDOMAIN));
?>